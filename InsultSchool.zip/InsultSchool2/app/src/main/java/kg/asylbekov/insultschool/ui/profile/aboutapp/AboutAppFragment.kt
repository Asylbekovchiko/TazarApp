package kg.asylbekov.insultschool.ui.profile.aboutapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import kg.asylbekov.insultschool.R
import kg.asylbekov.insultschool.base.BaseFragment
import kg.asylbekov.insultschool.data.api.info.AboutApi
import kg.asylbekov.insultschool.data.model.AboutApp
import kg.asylbekov.insultschool.data.state.State
import kg.asylbekov.insultschool.databinding.FragmentAboutAppBinding
import kg.asylbekov.insultschool.ui.profile.aboutapp.viewmodel.AboutAppViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel


class AboutAppFragment : BaseFragment<FragmentAboutAppBinding>(FragmentAboutAppBinding::inflate) {
    private val viewModel: AboutAppViewModel by viewModel()

    override fun init() {
        binding.profileToolbar.setNavigationOnClickListener {
            findNavController().navigate(R.id.action_aboutAppFragment_to_profileFragment)
        }
        viewModel.getAppInfo()
        viewModel.state.observe(this, Observer {state ->
        when(state){
            is State.LoadingState -> if (state.isLoading){
                println("Loading..")
            }else{
                println("Waiting..")
            }
            is State.ErrorState -> {
                println("Error")

            }
            is State.SuccessObjectState<*> ->{
                addData(state.data as AboutApp)
            }

//                when {
//                        state.data  is AboutApp -> {
//                    addData(state.data as AboutApp)
//                }
//
//
//            }

        }
        })
    }

    private fun addData(aboutApi: AboutApp) {
    binding.text.text = aboutApi.title
    }
}