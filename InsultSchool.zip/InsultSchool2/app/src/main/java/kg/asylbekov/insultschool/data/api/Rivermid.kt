package kg.asylbekov.insultschool.data.api

data class Rivermid(
    val question: String,
    val answer: Boolean
)
