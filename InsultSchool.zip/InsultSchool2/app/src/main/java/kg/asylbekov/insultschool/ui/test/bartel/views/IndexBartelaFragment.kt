package kg.asylbekov.insultschool.ui.test.bartel.views

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import kg.asylbekov.insultschool.R
import kg.asylbekov.insultschool.base.BaseFragment
import kg.asylbekov.insultschool.data.api.Bartela
import kg.asylbekov.insultschool.databinding.FragmentIndexBartelaBinding
import kg.asylbekov.insultschool.ui.test.bartel.adapter.BartelaAdapter

class IndexBartelaFragment : BaseFragment<FragmentIndexBartelaBinding>(FragmentIndexBartelaBinding::inflate) {

    private lateinit var adapter: BartelaAdapter
    private lateinit var list: ArrayList<Bartela>

    override fun init() {
        list = ArrayList()
        adapter = BartelaAdapter(list)
        binding.bartelTestRec.adapter = adapter

        list.add(Bartela("Who is ill?", "He","She","They"))
        list.add(Bartela("Who is ill?", "He","She","They"))
        list.add(Bartela("Who is ill?", "He","She","They"))
        list.add(Bartela("Who is ill?", "He","She","They"))
        list.add(Bartela("Who is ill?", "He","She","They"))
        list.add(Bartela("Who is ill?", "He","She","They"))
        list.add(Bartela("Who is ill?", "Hasdasde","She","They"))

        binding.bartelaToolbar.setNavigationOnClickListener {
            findNavController().navigate(R.id.action_indexBartelaFragment_to_testFragment)
        }

    }
}