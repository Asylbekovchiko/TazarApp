package kg.asylbekov.insultschool.data.api

data class NIHSS(
    val question: String,
    val f : String,
    val s : String,
    val t : String


)
