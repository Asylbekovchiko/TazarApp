package kg.asylbekov.insultschool.ui.test.bartel.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kg.asylbekov.insultschool.data.api.Bartela
import kg.asylbekov.insultschool.databinding.BartelaItemBinding

class BartelaAdapter(val list : ArrayList<Bartela>): RecyclerView.Adapter<BartelaAdapter.BartelaVH>() {

inner class BartelaVH(private val binding: BartelaItemBinding): RecyclerView.ViewHolder(binding.root){
    fun onBind(b: Bartela){
    binding.quesTitle.text = b.question
    binding.firstQuest.text = b.f_q
    binding.secondQuest.text = b.s_q
    binding.thirdQuest.text = b.t_q

    }
}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BartelaVH {
    val b = BartelaItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return BartelaVH(b)
    }

    override fun onBindViewHolder(holder: BartelaVH, position: Int) {
    holder.onBind(list[position])
    }

    override fun getItemCount(): Int {
    return list.size
    }
}