package kg.asylbekov.insultschool.modules

import android.content.Context
import kg.asylbekov.insultschool.app.AppModule.Companion.context
import kg.asylbekov.insultschool.data.api.auth.AuthApi
import kg.asylbekov.insultschool.data.api.info.AboutApi
import kg.asylbekov.insultschool.utils.UserManager
import kg.asylbekov.insultschool.utils.getUserToken
import okhttp3.Interceptor
import okhttp3.JavaNetCookieJar
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit


private val baseUrl = "http://school.intern.sunrisetest.online/"

        private fun getHttpLogInterceptor() = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

            val okHttpClients =  OkHttpClient.Builder().addInterceptor(getHttpLogInterceptor()).addInterceptor(AuthInterceptor())

        private fun getretrofit( ): Retrofit =
            Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .client(okHttpClients.build())
                .build()

        fun getRetrofit() = getretrofit()



        class AuthInterceptor : Interceptor {


            override fun intercept(chain: Interceptor.Chain): Response {
                val requestBuilder = chain.request().newBuilder()

                // If token has been saved, add it to the request
                getUserToken(context)?.let {
                    requestBuilder.addHeader("token", "Bearer $it")
                }

                return chain.proceed(requestBuilder.build())
            }
        }




/////
//SharedPrefs
//
//setToken(string)
//
//getToken(): String
//
//
//interceptor for header -> addinterceptor {
//    token = getToken -> Header("Authorization", "Token $token")

