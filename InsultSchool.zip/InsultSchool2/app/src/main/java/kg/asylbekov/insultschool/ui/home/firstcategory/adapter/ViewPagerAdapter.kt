package kg.asylbekov.insultschool.ui.home.firstcategory.adapter

import android.widget.BaseAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter

class ViewPagerAdapter(fm: FragmentManager?, lifecycle: Lifecycle, list: ArrayList<Fragment>): FragmentStateAdapter(fm!!, lifecycle) {
    val listFragment = list
    override fun getItemCount(): Int {
        return listFragment.size
    }

    override fun createFragment(position: Int): Fragment {
        return listFragment[position]
    }
}