package kg.asylbekov.insultschool.data.api

data class ImageApi (
    val url: String,
    val source: String
        )