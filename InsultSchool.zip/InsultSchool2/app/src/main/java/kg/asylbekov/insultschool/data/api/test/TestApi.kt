package kg.asylbekov.insultschool.data.api.test

import kg.asylbekov.insultschool.data.api.NIHSS
import retrofit2.Response
import retrofit2.http.GET

interface TestApi{

    @GET("v1/api/main/simple/test/")
    fun getBartelaTest(): Response<NIHSS>


}