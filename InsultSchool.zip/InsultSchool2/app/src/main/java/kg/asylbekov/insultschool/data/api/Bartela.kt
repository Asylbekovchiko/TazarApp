package kg.asylbekov.insultschool.data.api

data class Bartela(

    val question: String,
    val f_q : String,
    val s_q : String,
    val t_q : String
    )
