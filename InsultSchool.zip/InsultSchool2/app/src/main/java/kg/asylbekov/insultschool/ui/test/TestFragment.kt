package kg.asylbekov.insultschool.ui.test

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.navigation.fragment.findNavController
import kg.asylbekov.insultschool.R
import kg.asylbekov.insultschool.base.BaseFragment
import kg.asylbekov.insultschool.databinding.FragmentTestBinding
import kg.asylbekov.insultschool.databinding.FragmentTestsResultBinding


class TestFragment : BaseFragment<FragmentTestBinding>(FragmentTestBinding::inflate) {
    override fun init() {
        binding.testToolbar.setNavigationOnClickListener {
            findNavController().navigate(R.id.action_testFragment_to_homeFragment)
        }

        binding.indexBartela.setOnClickListener{
            findNavController().navigate(R.id.action_testFragment_to_indexBartelaFragment)
        }

        binding.nihhs.setOnClickListener {
            findNavController().navigate(R.id.action_testFragment_to_nihssFragment)
        }
        binding.rivermid.setOnClickListener {
            findNavController().navigate(R.id.action_testFragment_to_rivermidFragment)
        }
    }

}