package kg.asylbekov.insultschool.data.model

data class TestApi(
    val id: Int
)
