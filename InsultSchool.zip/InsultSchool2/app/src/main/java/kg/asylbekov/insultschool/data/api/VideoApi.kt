package kg.asylbekov.insultschool.data.api

data class VideoApi (
    val url: String,
    val title:  String

        )