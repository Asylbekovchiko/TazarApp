package kg.asylbekov.insultschool.ui.test.rivermid.views

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import kg.asylbekov.insultschool.R
import kg.asylbekov.insultschool.base.BaseFragment
import kg.asylbekov.insultschool.data.api.Rivermid
import kg.asylbekov.insultschool.databinding.FragmentRivermidBinding
import kg.asylbekov.insultschool.ui.test.rivermid.adapter.RivermidAdapter

class RivermidFragment : BaseFragment<FragmentRivermidBinding>(FragmentRivermidBinding::inflate) {
    private lateinit var adapter: RivermidAdapter
    private lateinit var list: ArrayList<Rivermid>

    override fun init() {
        list = ArrayList()
        adapter = RivermidAdapter(list)
        binding.rivermidRec.adapter = adapter
        list.add(Rivermid("ARE U OK?" , true))
        list.add(Rivermid("ARE U OK?" , true))
        list.add(Rivermid("ARE U OK?" , true))
        list.add(Rivermid("ARE U OK?" , true))
        list.add(Rivermid("ARE U OK?" , true))
        list.add(Rivermid("ARE U OK?" , true))
        list.add(Rivermid("ARE U OK?" , true))
        list.add(Rivermid("ARE U OK?" , true))

        binding.nihssToolbar.setNavigationOnClickListener {
            findNavController().navigate(R.id.action_rivermidFragment_to_testFragment)
        }
    }
}