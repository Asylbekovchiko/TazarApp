package kg.asylbekov.insultschool.data.api.info

import kg.asylbekov.insultschool.data.model.AboutApp
import retrofit2.Response
import retrofit2.http.GET

interface AboutApi {
    @GET("v1/api/info/about/")
    fun getInfoAboutApp(): Response<AboutApp>

}