package kg.asylbekov.insultschool.ui.registration.viewmodel

import android.app.Application
import android.content.Context
import android.net.sip.SipSession
import android.util.Log
import androidx.lifecycle.*
import kg.asylbekov.insultschool.app.AppModule.Companion.context
import kg.asylbekov.insultschool.data.model.Un
import kg.asylbekov.insultschool.data.model.UserNumber
import kg.asylbekov.insultschool.data.repository.AuthRepo
import kg.asylbekov.insultschool.data.state.State
import kg.asylbekov.insultschool.modules.viewModel
import kg.asylbekov.insultschool.utils.UserManager
import kg.asylbekov.insultschool.utils.saveUserToken
import kotlinx.coroutines.launch
import kotlin.coroutines.coroutineContext

    class SignInViewModel(application: Application, val repo: AuthRepo)  : AndroidViewModel(application) {

    private val _state: MutableLiveData<State> = MutableLiveData()
    val state: LiveData<State> = _state

    fun createUserByNum(num: String) {
        viewModelScope.launch {
            _state.value = State.LoadingState(true)
            val response = repo.createUserByNumber(num)
            when{
                response == null -> {
                    _state.value = State.ErrorState("", 0)
                }
                response.isSuccessful -> {
                    if(response.body() != null){
                    _state.value = State.SuccessObjectState(response.body())
                        val log = response.body()
                        saveUserToken(context,log!!.token)
                        println(log!!.token)
                        Log.d("AAA",log.token)
                    }else{
                        _state.value = State.NoItemState
                    }
                }
                else -> {

                }
            }
            _state.value = State.LoadingState(false)

        }
    }

}
