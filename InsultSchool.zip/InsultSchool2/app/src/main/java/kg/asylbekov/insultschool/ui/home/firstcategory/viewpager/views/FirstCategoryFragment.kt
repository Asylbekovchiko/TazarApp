package kg.asylbekov.insultschool.ui.home.firstcategory.viewpager.views

import android.content.res.Resources
import androidx.core.content.res.ResourcesCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.android.material.tabs.TabLayoutMediator
import kg.asylbekov.insultschool.R
import kg.asylbekov.insultschool.base.BaseFragment
import kg.asylbekov.insultschool.databinding.FragmentFirstCategoryBinding
import kg.asylbekov.insultschool.ui.home.firstcategory.adapter.ViewPagerAdapter
import kg.asylbekov.insultschool.ui.home.firstcategory.viewpager.FilesFragment
import kg.asylbekov.insultschool.ui.home.firstcategory.viewpager.image.ImageFragment
import kg.asylbekov.insultschool.ui.home.firstcategory.viewpager.text.TextFragment
import kg.asylbekov.insultschool.ui.home.firstcategory.viewpager.video.views.VideoFragment

class FirstCategoryFragment :
    BaseFragment<FragmentFirstCategoryBinding>(FragmentFirstCategoryBinding::inflate) {
    private lateinit var adapter: ViewPagerAdapter
    override fun init() {
       val  ist = ArrayList<Fragment>(
            listOf(
                VideoFragment(),
                ImageFragment(),
                TextFragment(),
                FilesFragment()
            )
        )
        adapter = ViewPagerAdapter(fragmentManager, lifecycle, list = ist)
        binding.viewpager.adapter = adapter
        binding.profileToolbar.setNavigationOnClickListener {
            findNavController().navigate(R.id.action_firstCategoryFragment_to_homeFragment)
        }
        TabLayoutMediator(binding.tabs, binding.viewpager) { tab, position ->
            if(position == 0){
                tab.text = "Видео"
                tab.icon = resources.getDrawable(R.drawable.ic_video_img)
            }else if(position == 1){
                tab.text = "Изображения"
                tab.icon = resources.getDrawable(R.drawable.ic_img_img)
            }else if(position == 2){
                tab.text = "Текст"
                tab.icon = resources.getDrawable(R.drawable.ic_text_img)

            }else{
                tab.text = "Файлы"
                tab.icon = resources.getDrawable(R.drawable.ic_files_img)

            }

        }.attach()


    }



}