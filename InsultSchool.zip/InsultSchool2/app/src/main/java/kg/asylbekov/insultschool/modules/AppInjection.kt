package kg.asylbekov.insultschool.modules

import android.annotation.SuppressLint
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import kg.asylbekov.insultschool.app.AppModule.Companion.context
import kg.asylbekov.insultschool.data.api.auth.AuthApi
import kg.asylbekov.insultschool.data.api.info.AboutApi
import org.koin.dsl.module
import retrofit2.Retrofit
import kotlin.coroutines.coroutineContext


        class AppInjection (context: Context){

        }
        val networkModule = module {

            val retrofit: Retrofit = getRetrofit()
             val AUTH_API: AuthApi = retrofit.create(AuthApi::class.java)
             val INFO_API: AboutApi = retrofit.create(AboutApi::class.java)

            single { AUTH_API }
            single { INFO_API }

        }





