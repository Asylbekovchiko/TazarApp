package kg.asylbekov.insultschool.ui.home.firstcategory.viewpager.video.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kg.asylbekov.insultschool.data.api.VideoApi
import kg.asylbekov.insultschool.databinding.VideoItemBinding

class VideoAdapter(val list: ArrayList<VideoApi>): RecyclerView.Adapter<VideoAdapter.VideoVH>() {

    inner class VideoVH(private val binding: VideoItemBinding): RecyclerView.ViewHolder(binding.root){
        fun onBind(l: VideoApi){

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoVH {
        val b = VideoItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VideoVH(b)
        }

    override fun onBindViewHolder(holder: VideoVH, position: Int) {
    holder.onBind(list[position])
    }

    override fun getItemCount(): Int {
    return list.size
    }
}