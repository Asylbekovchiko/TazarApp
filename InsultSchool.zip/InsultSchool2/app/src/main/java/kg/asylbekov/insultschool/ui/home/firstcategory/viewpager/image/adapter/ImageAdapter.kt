package kg.asylbekov.insultschool.ui.home.firstcategory.viewpager.image.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kg.asylbekov.insultschool.data.api.ImageApi
import kg.asylbekov.insultschool.databinding.ImageItemBinding

class ImageAdapter(val list: ArrayList<ImageApi>): RecyclerView.Adapter<ImageAdapter.ImageVH>(){
    inner class ImageVH(val b: ImageItemBinding): RecyclerView.ViewHolder(b.root){
        fun onBind(i: ImageApi){

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageVH {
    val a = ImageItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ImageVH(a)
    }

    override fun onBindViewHolder(holder: ImageVH, position: Int) {
    holder.onBind(list[position])
    }

    override fun getItemCount(): Int {
    return list.size
    }
}