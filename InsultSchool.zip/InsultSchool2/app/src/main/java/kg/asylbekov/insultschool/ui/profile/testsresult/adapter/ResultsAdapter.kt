package kg.asylbekov.insultschool.ui.profile.testsresult.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kg.asylbekov.insultschool.data.api.ApiEx
import kg.asylbekov.insultschool.databinding.ResultsItemBinding

class ResultsAdapter(var list: ArrayList<ApiEx>) :
    RecyclerView.Adapter<ResultsAdapter.ResultsVH>() {


    inner class ResultsVH(val binding: ResultsItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun onBind(a: ApiEx) {
            binding.nameTest.text = a.testname
            binding.userDateInfo.text = a.name
            binding.userScoreInfo.text = a.age.toString()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ResultsVH {
        val binding = ResultsItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ResultsVH(binding)
    }

    override fun onBindViewHolder(holder: ResultsVH, position: Int) {
        holder.onBind(list[position])
    }

    override fun getItemCount(): Int {
        return list.size
    }
}