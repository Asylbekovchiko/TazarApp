package kg.asylbekov.insultschool.ui.registration.signup.viewmodel

import android.net.sip.SipSession
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kg.asylbekov.insultschool.data.repository.AuthRepo
import kg.asylbekov.insultschool.data.state.State
import kotlinx.coroutines.launch

class SignUpUserInfoViewModel constructor(val repo: AuthRepo): ViewModel() {

    private val _state: MutableLiveData<State> = MutableLiveData()
    val state: LiveData<State> = _state

    fun updateUserInfo(fn: String, ln: String, g: String, b: String, token: String){
        viewModelScope.launch {
            _state.value = State.LoadingState(true)
            val response = repo.updateUserInfo(fn, ln, g, b, token)
            when{
                response == null -> {
                    _state.value = State.ErrorState("Error", 0)
                }
                response.isSuccessful -> {
                    if(response.body() != null){
                        _state.value = State.SuccessObjectState(response.body())
                    }else{
                        _state.value = State.NoItemState
                    }
                }
                else ->{
                    _state.value = State.ErrorState(response.errorBody().toString(), response.code())
                }
            }

        }
    }

}