package kg.asylbekov.insultschool.ui.registration

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import kg.asylbekov.insultschool.R
import kg.asylbekov.insultschool.base.BaseFragment
import kg.asylbekov.insultschool.data.model.Un
import kg.asylbekov.insultschool.databinding.FragmentSignInBinding
import kg.asylbekov.insultschool.ui.registration.viewmodel.SignInViewModel
import kg.asylbekov.insultschool.utils.UserManager
import org.koin.androidx.viewmodel.ext.android.viewModel


class SignUpNumFragment : BaseFragment<FragmentSignInBinding>(FragmentSignInBinding::inflate) {
    private val viewModel: SignInViewModel by viewModel()
    override fun init() {

        binding.signInToolbar.setNavigationOnClickListener {
            findNavController().navigate(R.id.action_signInFragment_to_homeFragment)
        }

        binding.goBtn.setOnClickListener {
            if (binding.numEdit.text.toString().length == 9) {
                val num = binding.numEdit.text.toString()
                viewModel.createUserByNum(num = num)
                findNavController().navigate(R.id.action_signInFragment_to_confirmNumberFragment)
            } else {
                Toast.makeText(activity, "Введите номер", Toast.LENGTH_SHORT).show()
            }

        }

    }
}