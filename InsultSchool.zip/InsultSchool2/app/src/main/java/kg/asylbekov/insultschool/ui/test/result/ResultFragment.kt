package kg.asylbekov.insultschool.ui.test.result

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kg.asylbekov.insultschool.R
import kg.asylbekov.insultschool.base.BaseFragment
import kg.asylbekov.insultschool.databinding.FragmentResultBinding

class ResultFragment : BaseFragment<FragmentResultBinding>(FragmentResultBinding::inflate) {

    override fun init() {

    }
}