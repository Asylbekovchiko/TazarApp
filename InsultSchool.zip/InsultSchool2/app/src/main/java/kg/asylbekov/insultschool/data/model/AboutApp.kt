package kg.asylbekov.insultschool.data.model

import com.google.gson.annotations.SerializedName

data class AboutApp(
    @SerializedName("title")
    val title: String? = null
)
