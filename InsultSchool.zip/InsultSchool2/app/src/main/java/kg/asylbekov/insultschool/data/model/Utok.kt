package kg.asylbekov.insultschool.data.model

import com.google.gson.annotations.SerializedName

data class Utok (
    @SerializedName("token")
    val token: String

        )