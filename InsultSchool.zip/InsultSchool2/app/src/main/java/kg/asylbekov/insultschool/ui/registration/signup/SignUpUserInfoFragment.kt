package kg.asylbekov.insultschool.ui.registration.signup

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isNotEmpty
import androidx.navigation.fragment.findNavController
import kg.asylbekov.insultschool.R
import kg.asylbekov.insultschool.base.BaseFragment
import kg.asylbekov.insultschool.databinding.FragmentConfirmNumberBinding
import kg.asylbekov.insultschool.databinding.FragmentSignUpBinding
import kg.asylbekov.insultschool.ui.registration.signup.viewmodel.SignUpUserInfoViewModel
import kg.asylbekov.insultschool.utils.getUserToken
import org.koin.androidx.viewmodel.ext.android.viewModel


class SignUpUserInfoFragment : BaseFragment<FragmentSignUpBinding>(FragmentSignUpBinding::inflate) {

    override fun init() {
        val viewModel: SignUpUserInfoViewModel by viewModel()

        binding.signInToolbar.setNavigationOnClickListener {
            findNavController().navigate(R.id.action_signUpFragment_to_signInFragment)
        }
        binding.saveBtn.setOnClickListener {
            val num = binding.number.text.toString()
            val lastName = binding.lastName.text.toString()
            val firstName = binding.firstName.text.toString()
            var gender = binding.spinnerGender.selectedItem.toString()
            if(gender == "Мужской"){
                gender = "male"
            }else{
                gender = "female"
            }

            val birthday = binding.birthday.text.toString()

            if (binding.number.text.isNotEmpty() && binding.lastName.text.isNotEmpty() && binding.firstName.text.isNotEmpty()

                && binding.birthday.text.isNotEmpty()
            ) {
                viewModel.updateUserInfo(fn =  firstName, ln = lastName, g = gender, birthday, token = getUserToken(requireContext())!! )
                println(getUserToken(requireContext()))
                findNavController().navigate(R.id.action_signUpFragment_to_testFragment)
            }else{
                Toast.makeText(activity, "Заполните поля", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
