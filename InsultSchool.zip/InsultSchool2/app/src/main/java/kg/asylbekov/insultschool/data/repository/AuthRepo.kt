package kg.asylbekov.insultschool.data.repository

import kg.asylbekov.insultschool.data.api.auth.AuthApi
import kg.asylbekov.insultschool.data.model.Un
import kg.asylbekov.insultschool.data.model.UserInfo
import kg.asylbekov.insultschool.data.model.UserNumber
import kg.asylbekov.insultschool.data.model.Utok
import retrofit2.Response
import java.lang.Exception

class AuthRepo(private var api: AuthApi) {

    suspend fun createUserByNumber(num: String): Response<UserNumber>? {
        return try {
            api.createUserByNumber(num)
        } catch (e: Exception) {
            null
        }
    }



    suspend fun updateUserInfo(f_name: String, l_name: String, gender: String, birthday: String, token: String): Response<UserInfo>?{
        return try {
            api.updateUserInfo(f_name,l_name,gender,birthday,token)
        }catch (e: Exception){
            null
        }
    }
}