package kg.asylbekov.insultschool.ui.profile.views

import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import kg.asylbekov.insultschool.R
import kg.asylbekov.insultschool.base.BaseFragment
import kg.asylbekov.insultschool.databinding.FragmentProfileBinding
import kg.asylbekov.insultschool.ui.MainActivity


class ProfileFragment : BaseFragment<FragmentProfileBinding>(FragmentProfileBinding::inflate) {
    override fun init() {

        setToolBar()
        binding.allTestResultsBtn.setOnClickListener {
            findNavController().navigate(R.id.action_profileFragment_to_testsResultFragment)
        }

        binding.aboutApp.setOnClickListener {
            findNavController().navigate(R.id.action_profileFragment_to_aboutAppFragment)
        }


    }

    private fun setToolBar() {
        setHasOptionsMenu(true)
        binding.profileToolbar.inflateMenu(R.menu.menu_toolbar)
        binding.profileToolbar.setNavigationIcon(R.drawable.ic_arrow_back)
        binding.profileToolbar.setNavigationOnClickListener {
            findNavController().navigate(R.id.action_profileFragment_to_homeFragment)
        }

        binding.profileToolbar.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.action_edit -> {
                    findNavController().navigate(R.id.action_profileFragment_to_editProfileFragment)
                    true
                }
                R.id.sign_out -> {
                    true
                }
                else -> false
            }
        }


    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_toolbar, menu)

    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_edit -> {
                true
            }
            R.id.sign_out -> {
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    //    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View? {
//        val activity = activity as AppCompatActivity
//        val t = activity.findViewById<Toolbar>(R.id.toolbarPartners)
//        activity.setSupportActionBar(t)
//        (activity as MainActivity).supportActionBar?.setDisplayHomeAsUpEnabled(true)
//        (activity as MainActivity).supportActionBar?.setDisplayShowTitleEnabled(false)
//
//        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_profile, container, false)
//    }


    private fun setssToolBar() {

//        val toolbarTitle = (activity as MainActivity).findViewById<TextView>(R.id.toolbar_title)

//        toolbarTitle.text = "Профиль"

    }


}