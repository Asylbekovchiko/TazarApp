package kg.asylbekov.insultschool.ui.test.nihss

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import kg.asylbekov.insultschool.R
import kg.asylbekov.insultschool.base.BaseFragment
import kg.asylbekov.insultschool.data.api.NIHSS
import kg.asylbekov.insultschool.databinding.FragmentNihssBinding
import kg.asylbekov.insultschool.ui.test.nihss.adapter.NihssAdapter


class NihssFragment : BaseFragment<FragmentNihssBinding>(FragmentNihssBinding::inflate) {
    private lateinit var adapter: NihssAdapter
    private lateinit var list : ArrayList<NIHSS>
    override fun init() {
        list = ArrayList()
        adapter = NihssAdapter(list)
        binding.nihssRec.adapter = adapter
        list.add(NIHSS("WHI IS HE", "TOM", "MIRBEK", "ALEX"))
        list.add(NIHSS("WHI IS HE", "TOM", "MIRBEK", "ALEX"))
        list.add(NIHSS("WHI IS HE", "TOM", "MIRBEK", "ALEX"))
        list.add(NIHSS("WHI IS HE", "TOM", "MIRBEK", "ALEX"))
        list.add(NIHSS("WHI IS HE", "TOM", "MIRBEK", "ALEX"))
        list.add(NIHSS("WHI IS HE", "TOM", "MIRBEK", "ALEX"))
        list.add(NIHSS("WHI IS HE", "TOM", "MIRBEK", "ALEX"))

        binding.nihssToolbar.setNavigationOnClickListener {
            findNavController().navigate(R.id.action_nihssFragment_to_testFragment)
        }


    }
}