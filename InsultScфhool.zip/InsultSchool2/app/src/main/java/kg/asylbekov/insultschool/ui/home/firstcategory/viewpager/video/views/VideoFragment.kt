package kg.asylbekov.insultschool.ui.home.firstcategory.viewpager.video.views

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kg.asylbekov.insultschool.R
import kg.asylbekov.insultschool.base.BaseFragment
import kg.asylbekov.insultschool.data.api.VideoApi
import kg.asylbekov.insultschool.databinding.FragmentVideoBinding
import kg.asylbekov.insultschool.ui.home.firstcategory.viewpager.video.adapter.VideoAdapter

class VideoFragment : BaseFragment<FragmentVideoBinding>(FragmentVideoBinding::inflate) {
    private lateinit var adapter: VideoAdapter
    private lateinit var list: ArrayList<VideoApi>
    override fun init() {
        list = ArrayList()
        adapter = VideoAdapter(list)
    binding.videoRec.adapter = adapter
        list.add(VideoApi("",""))
        list.add(VideoApi("",""))
        list.add(VideoApi("",""))
        list.add(VideoApi("",""))
        list.add(VideoApi("",""))
        list.add(VideoApi("",""))
        list.add(VideoApi("",""))

    }
}