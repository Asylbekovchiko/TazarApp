package kg.asylbekov.insultschool.data.repository

import kg.asylbekov.insultschool.data.api.info.AboutApi
import kg.asylbekov.insultschool.data.model.AboutApp
import retrofit2.Response
import java.lang.Exception

class InfoRepo(val api: AboutApi) {
    fun getInfoApp(): Response<AboutApp>?{
        return try {
            api.getInfoAboutApp()
        }catch (e: Exception){
            null
        }
    }

}