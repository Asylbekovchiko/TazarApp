package kg.asylbekov.insultschool.data.model

import com.google.gson.annotations.SerializedName

data class UserNumber(
    val phone: String,
    @SerializedName("token")
    val token: String
)
