package kg.asylbekov.insultschool.modules

import kg.asylbekov.insultschool.data.repository.AuthRepo
import kg.asylbekov.insultschool.data.repository.InfoRepo
import kg.asylbekov.insultschool.utils.UserManager
import org.koin.dsl.module

val repositoryModule = module {
    single { AuthRepo(get()) }
    single { InfoRepo(get()) }
}