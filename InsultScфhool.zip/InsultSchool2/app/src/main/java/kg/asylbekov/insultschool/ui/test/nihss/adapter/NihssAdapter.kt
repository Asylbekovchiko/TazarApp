package kg.asylbekov.insultschool.ui.test.nihss.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kg.asylbekov.insultschool.data.api.Bartela
import kg.asylbekov.insultschool.data.api.NIHSS
import kg.asylbekov.insultschool.databinding.BartelaItemBinding
import kg.asylbekov.insultschool.databinding.NihssItemBinding

class NihssAdapter(val list : ArrayList<NIHSS>): RecyclerView.Adapter<NihssAdapter.NihssVH>() {

    inner class NihssVH(private val binding: NihssItemBinding): RecyclerView.ViewHolder(binding.root){
        fun onBind(b: NIHSS){
            binding.quesTitle.text = b.question
            binding.firstQuest.text = b.f
            binding.secondQuest.text = b.s
            binding.thirdQuest.text = b.t

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NihssVH {
        val b = NihssItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NihssVH(b)
    }

    override fun onBindViewHolder(holder: NihssVH, position: Int) {
        holder.onBind(list[position])
    }

    override fun getItemCount(): Int {
        return list.size
    }
}