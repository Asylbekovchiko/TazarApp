package kg.asylbekov.insultschool.ui.profile.testsresult.views

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import kg.asylbekov.insultschool.R
import kg.asylbekov.insultschool.base.BaseFragment
import kg.asylbekov.insultschool.data.api.ApiEx
import kg.asylbekov.insultschool.databinding.FragmentTestsResultBinding
import kg.asylbekov.insultschool.ui.profile.testsresult.adapter.ResultsAdapter


class TestsResultFragment : BaseFragment<FragmentTestsResultBinding>(FragmentTestsResultBinding::inflate) {
    private lateinit var adapter : ResultsAdapter
    private lateinit var list: ArrayList<ApiEx>
    override fun init() {
        list = ArrayList<ApiEx>()
        adapter = ResultsAdapter(list)
        binding.resultsBinding.adapter = adapter
        list.add(ApiEx("1.01.2000", 20,"ИМ Ривермид"))
        list.add(ApiEx("1.01.2000", 20,"Индекс Бартела"))
        list.add(ApiEx("1.01.2000", 20,"Индекс Бартела"))
        list.add(ApiEx("1.01.2000", 20,"Индекс Бартела"))
        list.add(ApiEx("1.01.2000", 20,"Индекс Бартела"))
        list.add(ApiEx("1.01.2000", 20,"Индекс Бартела"))
        list.add(ApiEx("1.01.2000", 20,"Индекс Бартела"))
        list.add(ApiEx("1.01.2000", 20,"Индекс Бартела"))
        list.add(ApiEx("1.01.2000", 20,"Индекс Бартела"))

        binding.testResultToolbar.setNavigationOnClickListener {
            findNavController().navigate(R.id.action_testsResultFragment_to_profileFragment)
        }
    }

}