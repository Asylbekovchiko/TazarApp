package kg.asylbekov.insultschool.data.api

data class ApiEx(
val name: String,
val age : Int,
val testname: String
)