package kg.asylbekov.insultschool.modules

import kg.asylbekov.insultschool.ui.profile.aboutapp.viewmodel.AboutAppViewModel
import kg.asylbekov.insultschool.ui.registration.signup.viewmodel.SignUpUserInfoViewModel
import kg.asylbekov.insultschool.ui.registration.viewmodel.SignInViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val viewModel = module {

    viewModel { AboutAppViewModel(get()) }
    viewModel { SignInViewModel(get(),get()) }
    viewModel { SignUpUserInfoViewModel(get()) }

}