package kg.asylbekov.insultschool.data.model

import com.google.gson.annotations.SerializedName

data class UserInfo(
    val first_name : String,
    val last_name : String,
    val gender : String,
    val birthday : String,
)
