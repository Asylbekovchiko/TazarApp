package kg.asylbekov.insultschool.data.api.auth

import kg.asylbekov.insultschool.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface AuthApi {


    @FormUrlEncoded
    @POST("v1/api/auth/login/")
    suspend fun createUserByNumber(@Field("phone") phone: String): Response<UserNumber>



    @FormUrlEncoded
    @PUT("v1/api/auth/profile/")
     suspend fun updateUserInfo(
        @Field("first_name") first_name: String,
        @Field("last_name") last_name: String,
        @Field("gender") gender: String,
        @Field("birthday") birthday: String,

    ): Response<UserInfo>

    @GET("v1/api/auth/profile/")
    suspend fun readUSer(): Response<UserNumber>


    @GET("v1/api/auth/profile/")
    suspend fun partialUpdate(): Response<UserInfo>

    @GET("v1/api/auth/user/test/{id}/")
    suspend fun getTest(@Path("id") id: Int): Response<TestApi>

    @GET("v1/api/auth/user/tests/")
    suspend fun getListTests()

    ///
//    @GET("v1/api/auth/profile/")
//    suspend fun asd(
//        @Header()
//    ): Response<UserNumber>


}