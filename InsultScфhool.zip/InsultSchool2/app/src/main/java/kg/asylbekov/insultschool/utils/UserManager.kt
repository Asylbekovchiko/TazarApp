package kg.asylbekov.insultschool.utils

import android.content.Context
import android.content.SharedPreferences
import kg.asylbekov.insultschool.R

class UserManager() {


    companion object {
        const val USER_TOKEN = "token"
    }


}


fun saveUserToken(context: Context,token: String) {
    val editor = context.getSharedPreferences(context.getString(R.string.app_name), Context.MODE_PRIVATE).edit()
    editor.putString(UserManager.USER_TOKEN, token)
    editor.apply()
}

fun getUserToken(context: Context): String? {
    return context.getSharedPreferences(context.getString(R.string.app_name), Context.MODE_PRIVATE).getString(UserManager.USER_TOKEN, null)
}