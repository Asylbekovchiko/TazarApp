package kg.asylbekov.insultschool.ui.home.firstcategory.viewpager.image

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kg.asylbekov.insultschool.R
import kg.asylbekov.insultschool.base.BaseFragment
import kg.asylbekov.insultschool.data.api.ImageApi
import kg.asylbekov.insultschool.databinding.FragmentImageBinding
import kg.asylbekov.insultschool.ui.home.firstcategory.viewpager.image.adapter.ImageAdapter

class ImageFragment : BaseFragment<FragmentImageBinding>(FragmentImageBinding::inflate) {
    private lateinit var adapter: ImageAdapter
    private lateinit var lisArrayList: ArrayList<ImageApi>
    override fun init() {
        lisArrayList = ArrayList()
        adapter = ImageAdapter(lisArrayList)
        binding.imageRec.adapter = adapter
        lisArrayList.add(ImageApi("",""))
        lisArrayList.add(ImageApi("",""))
        lisArrayList.add(ImageApi("",""))
        lisArrayList.add(ImageApi("",""))
        lisArrayList.add(ImageApi("",""))
        lisArrayList.add(ImageApi("",""))
        lisArrayList.add(ImageApi("",""))
        lisArrayList.add(ImageApi("",""))
        lisArrayList.add(ImageApi("",""))
        lisArrayList.add(ImageApi("",""))
        lisArrayList.add(ImageApi("",""))

    }
}