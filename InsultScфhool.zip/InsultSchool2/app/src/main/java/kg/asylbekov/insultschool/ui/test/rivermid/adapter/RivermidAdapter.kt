package kg.asylbekov.insultschool.ui.test.rivermid.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kg.asylbekov.insultschool.data.api.NIHSS
import kg.asylbekov.insultschool.data.api.Rivermid
import kg.asylbekov.insultschool.databinding.NihssItemBinding
import kg.asylbekov.insultschool.databinding.RivermidItemBinding

class RivermidAdapter(val list : ArrayList<Rivermid>): RecyclerView.Adapter<RivermidAdapter.RivermidVH>() {

    inner class RivermidVH(private val binding: RivermidItemBinding): RecyclerView.ViewHolder(binding.root){
        fun onBind(b: Rivermid){
        binding.quesTitle.text = b.question
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RivermidVH {
        val b = RivermidItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RivermidVH(b)
    }

    override fun onBindViewHolder(holder: RivermidVH, position: Int) {
        holder.onBind(list[position])
    }

    override fun getItemCount(): Int {
        return list.size
    }
}